package dp01;

public interface CalcOperator {
	int operator(int a, int b);
	double operator(double a, double b);
}
