package teamproject02;

// 사람 인터페이스
public interface People {
	public abstract void deposit(int inmoney);		// 입금 메서드
	public abstract void withdraw(int outmoney);	// 출금 메서드
}
