package teamproject02;

// 사람 인터페이스
public interface People {
	public abstract void deposit();		// 입금 메서드
	public abstract void withdraw();	// 출금 메서드
}
